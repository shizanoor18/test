
<div class="row">
    <div class="col-sm-6">
        <div class="form-group">
            <label class="control-label col-md-4">
                <b>Title:</b>
            </label>
            <div class="col-md-8">
                <p class="form-control-static">
                    <?php 
                        echo (isset($post['title']) && !empty($post['title']) ? $post['title'] : '');
                    ?>
                </p>
            </div>
        </div>
    </div>
</div>
<div class="col-md-6 col-md-offset-6">
    <div class="" style="background-color: #f1f1f1;">
        <div class="form-group last">
            
            <div class="">
                <div class="fileupload fileupload-new" data-provides="fileupload">
                    <div class="fileupload-new thumbnail" >
                        <img style="max-width: 194px; max-height: 150px;" src="<?=(isset($post['image']) && !empty($post['image']) ? Modules::run('api/image_path_with_default',ACTUAL_PARTNERS_IMAGE_PATH,$post['image'],STATIC_FRONT_IMAGE,DEFAULT_WEBPAGES) : STATIC_FRONT_IMAGE.DEFAULT_WEBPAGES);?>" alt=""/>
                    </div>
                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;">
                    </div>
                
                </div>
            </div>
        </div>
    </div>
</div>