<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Partners extends MX_Controller{
	
	function __construct() {
		parent::__construct();
		Modules::run('site_security/is_login');
		Modules::run('site_security/has_permission');
	}

	function index() {
		$where=array();
		$data['query'] = $this->_get_records($where, 'id desc');
		$data['view_file'] = 'index';
		$this->load->module('template');
		$this->template->admin($data);
	}
	

	
	function create() {
		
		$update_id = $this->uri->segment(4);
		if (is_numeric($update_id) && $update_id != 0) {
			$data['partners'] = $this->_get_data_from_db($update_id);
		} else {
			$data['partners'] = $this->_get_data_from_post();
		}
		$data['update_id'] = $update_id;
		$data['view_file'] = 'create';
		$this->load->module('template');
		$this->template->admin($data);
	}

	function detail() {	
		$update_id = $this->input->post('id');
		$data['post'] = $this->_get_data_from_db($update_id);
		$this->load->view('detail', $data);
	}

	function submit() {
			$update_id = $this->input->post('update_id');
			$data = $this->_get_data_from_post();
			if ($update_id != 0) {
				
					$where['id'] = $update_id;
					$this->_update($where, $data);
					if(isset($_FILES['news_file']) && !empty($_FILES['news_file'])) {
        				if($_FILES['news_file']['size'] > 0) {
        					$old_image_name = $this->input->post('old_image_name');
        					if(!empty($old_image_name))
        						Modules::run('api/delete_images_by_name',ACTUAL_PARTNERS_IMAGE_PATH,LARGE_PARTNERS_IMAGE_PATH,MEDIUM_PARTNERS_IMAGE_PATH,SMALL_PARTNERS_IMAGE_PATH,$old_image_name);
        					Modules::run('api/upload_dynamic_image',ACTUAL_PARTNERS_IMAGE_PATH,LARGE_PARTNERS_IMAGE_PATH,MEDIUM_PARTNERS_IMAGE_PATH,SMALL_PARTNERS_IMAGE_PATH,$update_id,'news_file','image','id','partners');
        				}
        			}
					//$this->_update_icon($update_id);
					$this->session->set_flashdata('message', 'Page updated successfully.');
				
			}
			if ($update_id == 0) {
				$update_id = $this->_insert($data);
					if(isset($_FILES['news_file']) && !empty($_FILES['news_file'])) {
        				if($_FILES['news_file']['size'] > 0) {
        					Modules::run('api/upload_dynamic_image',ACTUAL_PARTNERS_IMAGE_PATH,LARGE_PARTNERS_IMAGE_PATH,MEDIUM_PARTNERS_IMAGE_PATH,SMALL_PARTNERS_IMAGE_PATH,$update_id,'news_file','image','id','partners');
        				}
        			}
					$this->session->set_flashdata('message', 'Page saved successfully.');
			}
			redirect(ADMIN_BASE_URL.'partners');
		
	}
		
	function change_status() {
		$id = $this->input->post('id');
		$status = $this->input->post('status');
		if ($status == 1)
			$status = 0;
		else {
			$status = 1;
		}
		$data = array('status' => $status);
		$status = $this->_update_id($id, $data);
		echo $status;
	}


	function delete() {
		$page_id = $this->input->post('id');
	
		$where_main_page['id'] = $page_id; 
		$result = $this->_delete($where_main_page);
	}
	function _get_data_from_db($update_id) {
		
		$where['id'] = $update_id;
		$query = $this->_get_by_arr_id($where);
		foreach ($query->result() as $row) {
			$data['image'] = $row->image;
			$data['title'] = $row->title;
			$data['link'] = $row->link;
			
		}
		return $data;
	}
	
	function _get_data_from_post() {
	    $data['title']=$this->input->post('title');
	    $data['link']=$this->input->post('link');
		return $data;
	}
	
	function _get_by_arr_id($arr_col) {
	$this->load->model('mdl_partners');
	return $this->mdl_partners->_get_by_arr_id($arr_col);
	}
	
	function _get_records($arr_col, $order_by) {
		$this->load->model('mdl_partners');
		return $this->mdl_partners->_get_records($arr_col, $order_by);
	}

	function _insert($data) {
		$this->load->model('mdl_partners');
		
		return $this->mdl_partners->_insert($data);
	}
	function _update($arr_col, $data) {
		$this->load->model('mdl_partners');
		$this->mdl_partners->_update($arr_col, $data);
	}
	
	function _update_id($id, $data) {
		$this->load->model('mdl_partners');
		$this->mdl_partners->_update_id($id, $data);
	}
	
	function _delete($arr_col) {
		$this->load->model('mdl_partners');
		$this->mdl_partners->_delete($arr_col);
	}
	
}