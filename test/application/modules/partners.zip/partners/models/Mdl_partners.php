<?php
/*************************************************
Modified By: Akabir Abbasi
Date: 17-12-2015
*************************************************/

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mdl_partners extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function get_table() {
        $table = "partners";
        return $table;
    }

    function _get_records($arr_col, $order_by) {
        $table = $this->get_table();
        $this->db->where($arr_col);
        $this->db->order_by($order_by);
        return $this->db->get($table);
    }
    function get($order_by) {
        $table = $this->get_table();
        $this->db->order_by($order_by);
        $query = $this->db->get($table);
        return $query;
    }
    function _insert($data) {
        $table = $this->get_table();
        $this->db->insert($table, $data);
        $inserted_id=$this->db->insert_id();
        return $inserted_id;
    }

    function _update($arr_col, $data) {
        $table = $this->get_table();
        $this->db->where($arr_col);
        $this->db->update($table, $data);
    }
    function _update_id($id, $data) {      
        $table = $this->get_table();
        $this->db->where('id = '.$id);
        $this->db->update($table, $data);
    }
	function _delete($arr_col) {
        $table = $this->get_table();
        $this->db->where($arr_col);
        $this->db->delete($table);
    }

    function _get_by_arr_id($arr_col) {
        $table = $this->get_table();
        $this->db->where($arr_col);
        return $this->db->get($table);
    }


}